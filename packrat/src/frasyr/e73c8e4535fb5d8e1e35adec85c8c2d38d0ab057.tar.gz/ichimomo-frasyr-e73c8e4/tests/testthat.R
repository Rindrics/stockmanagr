library(testthat)
library(frasyr)

test_check("frasyr")
